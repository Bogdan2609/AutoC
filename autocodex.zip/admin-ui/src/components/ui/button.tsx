import * as React from 'react'
import { Slot } from '@radix-ui/react-slot'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '@/lib/utils'

export const buttonVariants = cva(
  'inline-flex shrink-0 cursor-pointer items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[color,background-color,border-color,box-shadow] outline-none focus-visible:ring-[3px] focus-visible:ring-ring/40 focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0',
  {variants:{
    variant:{
      default:'bg-primary text-primary-foreground shadow-xs hover:opacity-90',
      outline:'border border-input bg-background text-foreground shadow-xs hover:bg-accent hover:text-accent-foreground',
      secondary:'bg-secondary text-secondary-foreground hover:bg-secondary/80',
      ghost:'text-foreground hover:bg-accent hover:text-accent-foreground',
      destructive:'bg-destructive text-white hover:bg-destructive/90',
      link:'text-foreground underline-offset-4 hover:underline'
    },
    size:{default:'h-9 px-4 py-2',sm:'h-8 gap-1.5 px-3 text-xs',lg:'h-10 px-5',icon:'size-9', 'icon-sm':'size-8'}
  },defaultVariants:{variant:'default',size:'default'}}
)
export function Button({className,variant,size,asChild=false,...props}:React.ComponentProps<'button'>&VariantProps<typeof buttonVariants>&{asChild?:boolean}) {
  const Component = asChild ? Slot : 'button'
  return <Component data-slot="button" className={cn(buttonVariants({variant,size,className}))} {...props}/>
}
