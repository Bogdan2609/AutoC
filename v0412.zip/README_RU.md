# AutoC v0.41.2 — Supplier Order Readback & Contract Verification

**База:** установленная и протестированная v0.41.0 (751 passed). **Формат:** безопасный локальный ZIP-патч без миграций, без реальных заказов/платежей. **Назначение:** read-only диагностика внешних заказов четырёх поставщиков с изоляцией API-аккаунтов.

## Состав

- Четыре транспорта чтения: ROSSKO GetOrders, ADEO getOrderStatus, PARTKOM basket/motion/{reference}, FORUM-AUTO listOrders.
- Строгие валидаторы внешних идентификаторов, ограничение тела ответа при потоковом скачивании, нормализация без PII и без автоподтверждения.
- Защищённая ручка админки `POST /api/v1/admin/marketplace/supplier-accounts/{account_id}/order-readback`, где POST означает только ручной запуск чтения с CSRF, **не запись поставщику**.
- Фильтры по конкретному API-аккаунту, разрешённому courier destination и собственному активному FulfillmentNode; квота Redis; секреты не отображаются.
- UI вкладка «Сверка заказов», тесты контрактов, версия, release gate, техническая документация.

## Docker / PowerShell (каждая команда в одну строку)

Поместите архив в `C:\Users\bogdan\Desktop\autocodex`, переименуйте в `v0412.zip`. Распаковывать не требуется.

Проверка:

```powershell
Set-Location 'C:\Users\bogdan\Desktop\autocodex'; docker run --rm -v "$($PWD.Path):/workspace" -w /workspace python:3.14.8-slim python -c "import zipfile,runpy,sys; zipfile.ZipFile('v0412.zip').extractall('/tmp/v0412'); sys.path.insert(0,'/tmp/v0412'); sys.argv=['/tmp/v0412/apply_v0412.py','--root','/workspace','--check']; runpy.run_path(sys.argv[0],run_name='__main__')"
```

Применение после успешной проверки:

```powershell
Set-Location 'C:\Users\bogdan\Desktop\autocodex'; docker run --rm -v "$($PWD.Path):/workspace" -w /workspace python:3.14.8-slim python -c "import zipfile,runpy,sys; zipfile.ZipFile('v0412.zip').extractall('/tmp/v0412'); sys.path.insert(0,'/tmp/v0412'); sys.argv=['/tmp/v0412/apply_v0412.py','--root','/workspace','--apply']; runpy.run_path(sys.argv[0],run_name='__main__')"
```

Docker rebuild:

```powershell
Set-Location 'C:\Users\bogdan\Desktop\autocodex'; docker compose up -d --build; if ($LASTEXITCODE -ne 0) { throw 'Docker build failed' }; docker compose ps
```

Контрактные и API тесты:

```powershell
Set-Location 'C:\Users\bogdan\Desktop\autocodex'; docker compose exec -T -e TEST_DATABASE_URL= web uv run --no-dev --no-sync --with pytest --with pytest-asyncio --with aiosqlite python -m pytest tests/test_supplier_order_readback_v0412.py tests/test_supplier_readback_api_v0412.py -q -p no:cacheprovider
```

Полная регрессия:

```powershell
Set-Location 'C:\Users\bogdan\Desktop\autocodex'; docker compose exec -T -e TEST_DATABASE_URL= web uv run --no-dev --no-sync --with pytest --with pytest-asyncio --with aiosqlite python -m pytest tests -q -p no:cacheprovider
```

Gate:

```powershell
Set-Location 'C:\Users\bogdan\Desktop\autocodex'; docker compose exec -T web python scripts/release_gate_v0412.py --check-http
```

## Безопасность

Операции закупки и отмены не реализованы и не вызываются из нового readback. Все выводы поставщика сохраняют `supplier_confirmed=false` и `manual_reconciliation_required=true`, никакие статусы в БД не меняются. Отсутствие внешнего заказа в ответе не доказывает, что заказ не был отправлен. Новые HTTP-чтения выполняются **только оператором** при включённых supplier API и Redis-лимитах; при `APP_ENV=test` внешняя сеть запрещена.

Документация из `sups(1).zip` — исходное описание API, но живые права конкретного аккаунта/маршрута не подтверждены. **LIVE PAYMENTS / LIVE SUPPLIER WRITES: NO_GO**, PostgreSQL race-тесты остаются нерешённым выпускным критерием.
