"""Anchored safe transformations from a user-installed AutoC v0.41.0 tree."""
from __future__ import annotations


def once(s: str, old: str, new: str, path: str) -> str:
    n=s.count(old)
    if n!=1:
        raise ValueError(f'{path}: required anchor missing/ambiguous (count {n}): {old[:110]!r}')
    return s.replace(old,new,1)


def transform(path: str, source: str) -> str:
    s=source
    def r(a,b):
        nonlocal s
        s=once(s,a,b,path)
    if path=='app/modules/marketplace/account_probe.py':
        if 'async def supplier_integration_readiness(' not in s or "@router.get('/supplier-integrations/capabilities')" not in s:
            raise ValueError('v0.41 account diagnostics missing')
        s+='''

class SupplierOrderReadbackInput(BaseModel):
    destination_id: UUID
    external_reference: str = Field(min_length=1, max_length=80)


@router.post('/supplier-accounts/{account_id}/order-readback')
async def supplier_order_readback(account_id: UUID, body: SupplierOrderReadbackInput,
                                  db: AsyncSession = Depends(get_session)):
    """Explicit operator-initiated READ only. Never changes a purchase/order.

    POST is used only to protect input from URL logs and trigger staff CSRF.
    Reject any unverified account/destination before contacting the provider.
    """
    from app.integrations.suppliers.factory import SupplierFactory, SupplierBindingError
    from app.integrations.suppliers.order_readback import (
        ReadbackError, normalize_order, validate_reference)
    from app.integrations.suppliers.order_transport import read_external_order
    from app.modules.marketplace.models import SupplierDestination, FulfillmentNode
    from app.modules.offer_engine.discovery import claim_supplier_budget
    from app.core.config import get_settings
    if not get_settings().supplier_api_enabled or get_settings().app_env == 'test':
        raise HTTPException(403, 'Live supplier order reads disabled')
    account = await db.get(SupplierAccount, account_id)
    dest = await db.get(SupplierDestination, body.destination_id)
    supplier = await db.get(Supplier, account.supplier_id) if account else None
    node = await db.get(FulfillmentNode, dest.node_id) if dest else None
    if not all((account, dest, supplier, node)):
        raise HTTPException(404, 'Supplier route not found')
    try:
        ref = validate_reference(supplier.code, body.external_reference)
        binding = SupplierFactory().for_search(
            supplier.code,supplier=supplier,account=account,destination=dest,node=node)
    except (ReadbackError, SupplierBindingError, ValueError):
        raise HTTPException(409, 'Supplier readback route or order reference invalid') from None
    if not binding.scoped:
        raise HTTPException(409, 'Account-scoped readback required')
    if not await claim_supplier_budget(supplier.code, str(account.id), account.requests_per_hour):
        raise HTTPException(429, 'Supplier read budget exhausted')
    config=binding.config
    await db.commit()  # Never hold a database transaction across provider HTTP.
    try:
        raw=await read_external_order(supplier.code, config, ref)
        result=normalize_order(supplier.code, ref, raw)
    except Exception:
        # Never surface supplier URL (Forum credentials may be in query),
        # supplier raw XML/JSON, network diagnostics or private fields.
        raise HTTPException(503, 'Supplier order readback unavailable or inconclusive') from None
    return {'account_id': str(account.id), 'destination_id': str(dest.id),
            **result.public(), 'stored_changes': False,
            'operator_action': 'Verify buyer order, exact SKU, quantities and courier evidence separately'}
'''
        r('from fastapi import APIRouter, Depends, HTTPException',
          'from fastapi import APIRouter, Depends, HTTPException\nfrom pydantic import BaseModel, Field')
    elif path=='app/integrations/suppliers/diagnostics.py':
        r("return {'version': '0.41.0', 'suppliers': capabilities_matrix(),",
          "return {'version': '0.41.2', 'suppliers': [dict(feature, documented_order_readback=True,\n             manual_readback_endpoint_available=True, auto_supplier_confirmation=False)\n             for feature in capabilities_matrix()],")
    elif path=='admin-ui/src/pages/SupplierControl.tsx':
        r("type Batch={id:string;original_name:string;supplier:string;status:string}",
          "type Batch={id:string;original_name:string;supplier:string;status:string}\ntype ReadbackDestination={id:string;account_id:string;node:string;enabled:boolean;verified:boolean}")
        r(" const gateway=useQuery({queryKey:['supplier-gateway-v041'],queryFn:()=>api<GatewayMatrix>('/api/v1/admin/marketplace/supplier-integrations/capabilities')})",
          " const [readAccount,setReadAccount]=useState('');const [readDest,setReadDest]=useState('');const [readRef,setReadRef]=useState('')\n const routes=useQuery({queryKey:['readback-destinations-v0412'],queryFn:()=>api<ReadbackDestination[]>(`${WORKSPACE}/destinations`)})\n const gateway=useQuery({queryKey:['supplier-gateway-v041'],queryFn:()=>api<GatewayMatrix>('/api/v1/admin/marketplace/supplier-integrations/capabilities')})")
        r(' return <><Link to="/suppliers"', ''' async function readOrder(){
  if(!readAccount||!readDest||!readRef.trim())return
  if(!window.confirm('Запросить только чтение конкретного заказа поставщика? Запрос использует лимит API, не оформляет и не отменяет заказ.'))return
  setBusy(true);setError('');setDetails(null)
  try{setDetails(await api<unknown>(`/api/v1/admin/marketplace/supplier-accounts/${readAccount}/order-readback`,{method:'POST',body:JSON.stringify({destination_id:readDest,external_reference:readRef.trim()})}))}
  catch(e){setError(e instanceof Error?e.message:'Supplier readback unavailable')}
  finally{setBusy(false)}
 }
 return <><Link to="/suppliers"''')
        r('<TabsTrigger value="capabilities">Фабрика API</TabsTrigger><TabsTrigger value="mapping">Привязки прайсов</TabsTrigger>',
          '<TabsTrigger value="capabilities">Фабрика API</TabsTrigger><TabsTrigger value="readback">Сверка заказов</TabsTrigger><TabsTrigger value="mapping">Привязки прайсов</TabsTrigger>')
        r(' <TabsContent value="mapping"><div className="grid gap-4 xl:grid-cols-2">', ''' <TabsContent value="readback"><Card><CardHeader><CardTitle>Сверка заказа по внешнему ID</CardTitle><CardDescription>Запрос к выбранному API-аккаунту и разрешённому складу. Только чтение: ответ не меняет статус заказа AutoC и не разрешает повторную закупку.</CardDescription></CardHeader><CardContent className="space-y-3">
 <select aria-label="Аккаунт для сверки" className="h-10 w-full rounded-lg border bg-background px-3 text-sm" value={readAccount} onChange={e=>{setReadAccount(e.target.value);setReadDest('')}}><option value="">Выберите API-аккаунт</option>{(accounts.data??[]).filter(a=>a.enabled&&a.read_enabled).map(a=><option key={a.id} value={a.id}>{a.supplier_code} · {a.label}</option>)}</select>
 <select aria-label="Курьерское направление для сверки" className="h-10 w-full rounded-lg border bg-background px-3 text-sm" value={readDest} onChange={e=>setReadDest(e.target.value)}><option value="">Выберите подтверждённое направление</option>{(routes.data??[]).filter(d=>d.account_id===readAccount&&d.enabled&&d.verified).map(d=><option key={d.id} value={d.id}>{d.node} · {shortId(d.id)}</option>)}</select>
 <input aria-label="Внешний идентификатор заказа" className="h-10 w-full rounded-lg border bg-background px-3 text-sm" placeholder="ROSSKO/ADEO/FORUM: ID; PARTKOM: reference" maxLength={80} value={readRef} onChange={e=>setReadRef(e.target.value)}/>
 <Button disabled={busy||!readAccount||!readDest||!readRef.trim()} onClick={()=>void readOrder()}><Activity size={15}/> Прочитать статус без изменений</Button><p className="text-xs text-muted-foreground">Результат — только диагностическое наблюдение. Отсутствие записи не доказывает отсутствие закупки. Проверка API может быть отключена в настройках.</p>
 </CardContent></Card></TabsContent>
 <TabsContent value="mapping"><div className="grid gap-4 xl:grid-cols-2">''')
    elif path=='app/main.py':
        r("api_version = '0.41.0'  # local source checkout without installed wheel",
          "api_version = '0.41.2'  # local source checkout without installed wheel")
    elif path=='pyproject.toml':
        r('version = "0.41.0"','version = "0.41.2"')
    else:
        raise ValueError(f'Unsupported patch target: {path}')
    if s==source:
        raise ValueError('No change')
    return s
