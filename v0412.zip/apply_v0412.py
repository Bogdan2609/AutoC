"""AutoC v0.41.2 guarded, transactional source installer (not a DB transaction).

Runs in a throwaway Docker Python container, with the project bind-mounted.
Never imports application modules or contacts suppliers/banks/DB.
"""
from __future__ import annotations
import argparse
import ast
from datetime import datetime, timezone
import hashlib
from pathlib import Path
import shutil
import sys
import tomllib
from transform import transform

HERE=Path(__file__).resolve().parent
PAYLOAD=HERE/'payload'
MODIFIED=(
    'app/modules/marketplace/account_probe.py',
    'app/integrations/suppliers/diagnostics.py',
    'admin-ui/src/pages/SupplierControl.tsx',
    'app/main.py',
    'pyproject.toml',
)
BASE_HASH={
    # Original v0.41 payload must match exactly: reject local changes.
    'app/integrations/suppliers/diagnostics.py': hashlib.sha256(
        (HERE/'diagnostics_v041_baseline.py').read_bytes()).hexdigest(),
}


def stage(root: Path):
    pyproject=root/'pyproject.toml'
    if not pyproject.is_file():
        raise RuntimeError('AutoC root pyproject.toml missing')
    version=tomllib.loads(pyproject.read_text('utf-8'))['project']['version']
    if version!='0.41.0':
        raise RuntimeError(f'AutoC v0.41.0 prerequisite missing: current version {version}')
    planned={}
    for rel in MODIFIED:
        path=root/rel
        original=path.read_bytes()
        normalized=original.replace(b'\r\n',b'\n')
        if rel in BASE_HASH and hashlib.sha256(normalized).hexdigest()!=BASE_HASH[rel]:
            raise RuntimeError(f'{rel}: v0.41 baseline modified; refusing to overwrite')
        content=transform(rel,normalized.decode('utf8'))
        if rel.endswith('.py'):
            ast.parse(content,filename=rel)
        if rel.endswith('.toml'):
            tomllib.loads(content)
        if b'\r\n' in original:
            content=content.replace('\n','\r\n')
        planned[path]=content.encode('utf8')
    for source in sorted(PAYLOAD.rglob('*')):
        if not source.is_file() or '__pycache__' in source.parts:
            continue
        rel=source.relative_to(PAYLOAD)
        target=root/rel
        if target.exists():
            raise RuntimeError(f'New release file already exists: {rel}')
        blob=source.read_bytes()
        if source.suffix=='.py':
            ast.parse(blob.decode('utf8'),filename=str(rel))
        planned[target]=blob
    return planned


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,default=Path.cwd())
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--check',action='store_true')
    mode.add_argument('--apply',action='store_true')
    args=parser.parse_args()
    root=args.root.resolve()
    planned=stage(root)
    print(f'AutoC v0.41.2 preflight PASS: {len(planned)} files, base v0.41.0')
    for file in planned:
        print(' ',file.relative_to(root))
    if args.check:
        return
    backup=root/'_autoc_v0412_backups'/datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
    originals=[path for path in planned if path.exists()]
    completed=[]
    created={path for path in planned if not path.exists()}
    try:
        for path in originals:
            dest=backup/path.relative_to(root)
            dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(path,dest)
        for path,value in planned.items():
            path.parent.mkdir(parents=True,exist_ok=True)
            tmp=path.with_name(path.name+'.v0412_tmp')
            try:
                tmp.write_bytes(value)
                tmp.replace(path)
            finally:
                tmp.unlink(missing_ok=True)
            completed.append(path)
    except BaseException:
        for path in reversed(completed):
            if path in created:
                path.unlink(missing_ok=True)
            else:
                shutil.copy2(backup/path.relative_to(root),path)
        raise
    print(f'v0.41.2 source applied. Backup: {backup}')
    print('No migrations, external API calls, orders, financial writes or credential changes.')
    print('LIVE PAYMENTS / SUPPLIER PURCHASES: NO_GO')


if __name__=='__main__':
    main()
